/// <reference path="../../../public/app/headers/common.d.ts" />
declare const _default: any;
export default _default;
